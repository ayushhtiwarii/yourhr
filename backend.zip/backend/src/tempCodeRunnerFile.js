er("index");

        // Delete the file fr